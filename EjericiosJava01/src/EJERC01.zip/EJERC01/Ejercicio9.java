package EJERC01;
import java.util.Scanner;

public class Ejercicio9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leer = new Scanner(System.in);
		float pst = 0;
		System.out.println("Ingrese el numero de euros");
		float eu = leer.nextInt();
		
		pst = eu*166;
			System.out.println("Usted tiene " + pst + "es pesetas");

		}
	{

}
}
